import random
import json

# List of agent names
agent_names = ["Alex", "Taylor", "Jordan", "Morgan", "Sam"]

# Load responses from a JSON file (can be extended easily)
def load_responses():
    return {
        "coffee": "The campus coffee bar is open from 8 AM to 6 PM.",
        "library": "The library is open from 7 AM to 10 PM. You can find study spaces and resources there.",
        "courses": "You can find information about our courses on the university website.",
        "fees": "Tuition fees depend on the course. Please visit the fees section on our website for more details.",
    }

# Generic random responses
random_responses = [
    "That's interesting! Tell me more.",
    "I'm not sure about that. Could you elaborate?",
    "That's a great question! Let me think...",
    "Hmm, I don't have the answer to that right now.",
]

def main():
    # Load responses
    responses = load_responses()

    # Greet the user
    user_name = input("Hi there! What's your name? ")
    print(f"Hello, {user_name}! Welcome to the University of Poppleton chatbot.")

    # Assign a random agent name
    agent_name = random.choice(agent_names)
    print(f"You are now chatting with {agent_name}. How can I assist you today?")

    # Start chat loop
    chat_log = []
    while True:
        user_input = input(f"{user_name}: ").strip().lower()

        # Log user input
        chat_log.append({"user": user_input})

        # Exit condition
        if user_input in ["bye", "quit", "exit"]:
            print(f"{agent_name}: It was nice chatting with you, {user_name}. Goodbye!")
            break
        for keyword, reply in responses.items():
            if keyword in user_input:
                response = reply
                break

        # If no keyword found, give a random response
        if response is None:
            response = random.choice(random_responses)

        # Include user's name in some responses
        if random.choice([True, False]):
            response = f"{user_name}, {response}"

        print(f"{agent_name}: {response}")

        # Log agent response
        chat_log.append({"agent": response})

    # Save chat log to a file
    with open("chat_log.txt", "w") as log_file:
        for entry in chat_log:
            log_file.write(f"{entry}\n")

if __name__ == "__main__":
    main()
