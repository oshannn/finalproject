# exercise . 6

import os
import sys
print(dir(os))