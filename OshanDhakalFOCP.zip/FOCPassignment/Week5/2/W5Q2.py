# exercise .2

import sys
args = sys.argv[1:]
print(args)