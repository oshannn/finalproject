# exercise .4

import sys
print(dir(sys))