# exercise .5

import sys
from statistics import mean
args = sys.argv[1:]
if len(args) == 0:
    print("No temperatures entered!")
else:
    temperatues = list(map(float, args))
    max_temp = max(temperatues)
    min_temp = min(temperatues)
    mean_temp = mean(temperatues)
    print(f"The max temperature is: {max_temp},\nThe min temperature is: {min_temp},\nThe mean temperature is: {mean_temp}")
