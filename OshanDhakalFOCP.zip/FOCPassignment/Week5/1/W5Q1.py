# exercise .1

import sys
print(sys.platform)