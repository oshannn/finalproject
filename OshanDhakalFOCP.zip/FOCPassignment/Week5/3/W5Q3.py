# exercise .3

import sys
args = sys.argv[1:]
print(sorted(list(map(float, args)))[0])
