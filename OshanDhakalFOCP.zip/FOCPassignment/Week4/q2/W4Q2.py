# exercise.2

def case_checker(entered_string):
    """This function takes in a string and counts the number of uppercase and lowercase letters in it."""
    for char in entered_string:
        print(char)


case_checker("AAAAsssss")