# exercise.4

def char_remover(string):
    """This function takes in a string as a parameter and removes the last character of the string if its length is longer than 1."""

    if len(string) > 1:
        return print(f"String with the last letter removed: {string[:-1]}")
    else:
        return print("No changes")


entered_string = input("Enter a string: ")

char_remover(entered_string)
