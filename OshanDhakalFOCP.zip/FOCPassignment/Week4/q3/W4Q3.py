# exercise.3

def case_manager(name):
    """This function takes in a string as a parameter and changes the first character to uppercase and the rest to lowercase."""

    return name[0].upper() + name[1:].lower()


entered_name = input('Hello, What is your name? ')

print(f"Hello, {case_manager(entered_name)}. Good to meet you!")