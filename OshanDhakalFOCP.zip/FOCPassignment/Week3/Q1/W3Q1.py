# exercise.1
name = input("Enter your name: ")
if name:
    print(f"Hello, {name}!")
else:
    print("Hello, Stranger!")