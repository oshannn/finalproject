# exercise .6
num = int(input("Enter a number: "))
for i in range(0, 13):
    print(f"{i} x {num} = {i*num}")