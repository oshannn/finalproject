# exercise .2
password = input("Enter your password: ")
confirm_password = input("Confirm your password: ")

if password == confirm_password:
    print("Password Set")
else:
    print("Incorrect password")