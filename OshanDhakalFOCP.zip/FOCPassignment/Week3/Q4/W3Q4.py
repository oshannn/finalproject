# exercise .4
BAD_PASSWORDS = ['password', 'letmein', 'sesame', 'hello', 'justinbieber']
pass1 = input("Enter a new password (between 8-12 characters): ")
if 8 <= len(pass1) <= 12:
    if pass1 not in BAD_PASSWORDS:
        pass2 = input("Confirm your password: ")
        if pass1 == pass2:
            print("Password Successfully Set")
        else:
            print("Error: Passwords do not match. Please try again.")
    else:
        print("Error: Common password. Please choose a strong password.")
else:
    print("Error: Password must be between 8 and 12 characters long.")