# exercise .7
num = int(input("Enter a number: "))
if num in range(0, 13):
    for i in range(0, 13):
        print(f"{i} x {num} = {i*num}")
else:
    print("Please enter a number between range 0-12")
