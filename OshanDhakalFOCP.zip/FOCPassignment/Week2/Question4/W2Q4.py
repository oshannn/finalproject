# Question no.4
num_students = int(input("How many students? "))
num_sweets = int(input("how many sweets ? "))
sweets_per_student = num_sweets // num_students
remaining_sweets = num_sweets % num_students
print("Each student should receive " + str(sweets_per_student) + " sweets and " + str(remaining_sweets) + "will be leftovers.")