 # Question no.1

name = input("Hello, what is your name? ")
print("Hello " + name + ". Good to meet you!")
