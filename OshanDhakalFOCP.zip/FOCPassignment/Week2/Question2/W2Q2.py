# Question no.2 

celsius = int(input("Enter the Temperature in Celsius:\n"))
fahrenheit = (1.8 * celsius) + 32
print(str(celsius) + " is equivalent to " + str(fahrenheit) + " Fahrenheit.")