# Question no.3

num_std = 113
req_size = 22
groups = num_std // req_size
remaining_students = num_std % req_size
print("There will be " + str(groups) + " groups and " + str(remaining_students) + " leftovers.")